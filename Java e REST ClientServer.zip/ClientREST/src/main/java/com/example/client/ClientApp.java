package com.example.client;

import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

public class ClientApp {
    private static final String SERVER_URL = "http://localhost:8080/api/items";

    public static void main(String[] args) {
        Client client = ClientBuilder.newClient();

        // Aggiungere un item
        Response postResponse = client.target(SERVER_URL)
                .request(MediaType.APPLICATION_JSON)
                .post(Entity.json("Nuovo Elemento"));

        System.out.println("Risposta POST: " + postResponse.readEntity(String.class));

        // Ottenere la lista
        String items = client.target(SERVER_URL)
                .request(MediaType.APPLICATION_JSON)
                .get(String.class);

        System.out.println("Lista Items: " + items);
    }
}
