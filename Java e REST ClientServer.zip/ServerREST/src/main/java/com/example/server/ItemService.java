package com.example.server;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

@Path("/items")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ItemService {
    private static final String FILE_PATH = "src/main/resources/data.json";
    private static final Gson gson = new Gson();
    private static List<String> items = loadItems();

    // Metodo GET per ottenere tutti gli elementi
    @GET
    public List<String> getItems() {
        return items;
    }

    // Metodo POST per aggiungere un elemento
    @POST
    public String addItem(String item) {
        items.add(item);
        saveItems();
        return "Item aggiunto!";
    }

    // Metodo DELETE per rimuovere un elemento per indice
    @DELETE
    @Path("/{index}")
    public String removeItem(@PathParam("index") int index) {
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            saveItems();
            return "Item rimosso!";
        }
        return "Indice non valido!";
    }

    // Metodo per leggere gli elementi dal file JSON
    private static List<String> loadItems() {
        try (Reader reader = new FileReader(FILE_PATH)) {
            Type listType = new TypeToken<List<String>>() {}.getType();
            List<String> data = gson.fromJson(reader, listType);
            return (data != null) ? data : new ArrayList<>();
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    // Metodo per salvare gli elementi nel file JSON
    private static void saveItems() {
        try (Writer writer = new FileWriter(FILE_PATH)) {
            gson.toJson(items, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
